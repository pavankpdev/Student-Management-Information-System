<?php

//fetch_data.php

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

$method = $_SERVER['REQUEST_METHOD'];

if($method == 'GET')
{
 $data = array(
  ':Reg_no'   => "%" . $_GET['Reg_no'] . "%",
  ':month'   => "%" . $_GET['month'] . "%",
  ':Engg_maths1'     => "%" . $_GET['Engg_maths1'] . "%",
  ':Science'    => "%" . $_GET['Science'] . "%",
  ':Ceee'    => "%" . $_GET['Ceee'] . "%",
  ':Be_lab'    => "%" . $_GET['Be_lab'] . "%",
  ':Science_lab'    => "%" . $_GET['Science_lab'] . "%",
  ':Bcs_lab'    => "%" . $_GET['Bcs_lab'] . "%" 
 );
 $query = "SELECT * FROM sem1internal1";

 $statement = $connect->prepare($query);
 $statement->execute($data);
 $result = $statement->fetchAll();
 foreach($result as $row)
 {
  $output[] = array(
   'Reg_no'    => $row['Reg_no'],   
   'month'  => $row['month'],
   'Engg_maths1'   => $row['Engg_maths1'],
   'Science'    => $row['Science'],
   'Ceee'   => $row['Ceee']
   'Be_lab'   => $row['Be_lab']
   'Science_lab'   => $row['Science_lab']
   'Bcs_lab'   => $row['Bcs_lab']
  );
 }
 header("Content-Type: application/json");
 echo json_encode($output);
}

if($method == "POST")
{
 $data = array(
  ':first_name'  => $_POST['first_name'],
  ':last_name'  => $_POST["last_name"],
  ':age'    => $_POST["age"],
  ':gender'   => $_POST["gender"]
 );

 $query = "INSERT INTO sample_data (first_name, last_name, age, gender) VALUES (:first_name, :last_name, :age, :gender)";
 $statement = $connect->prepare($query);
 $statement->execute($data);
}

if($method == 'PUT')
{
 parse_str(file_get_contents("php://input"), $_PUT);
 $data = array(
  ':id'   => $_PUT['id'],
  ':first_name' => $_PUT['first_name'],
  ':last_name' => $_PUT['last_name'],
  ':age'   => $_PUT['age'],
  ':gender'  => $_PUT['gender']
 );
 $query = "
 UPDATE sample_data 
 SET first_name = :first_name, 
 last_name = :last_name, 
 age = :age, 
 gender = :gender 
 WHERE id = :id
 ";
 $statement = $connect->prepare($query);
 $statement->execute($data);
}

if($method == "DELETE")
{
 parse_str(file_get_contents("php://input"), $_DELETE);
 $query = "DELETE FROM sample_data WHERE id = '".$_DELETE["id"]."'";
 $statement = $connect->prepare($query);
 $statement->execute();
}

?>
