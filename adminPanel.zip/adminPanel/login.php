<html>
<head>
<title>Login - STUDENT MIS</title>
<link href="login.css" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="logo.png" id="icon" alt="User Icon" /><br>
      <b>Student M.I.S<br>S.J(GOVT.) POLYTECHNIC</b>
    </div>
    <br>
    <!-- Login Form -->
    <form method="POST" action="http://localhost/M.I.S/admin_authen_login.php">
      <input type="text" class="fadeIn second" name="username" placeholder="username">
      <input type="password" class="fadeIn third" name="password" placeholder="password">
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#">Forgot Password?</a>
    </div>

  </div>
</div>
</body>
</html>